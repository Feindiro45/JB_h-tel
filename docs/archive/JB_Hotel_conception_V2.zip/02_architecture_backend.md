# JB Hôtel — Architecture backend V2
## Stack
Laravel API REST, MySQL ou PostgreSQL, migrations, transactions SQL, authentification Sanctum, politiques d'autorisation par rôle, journal d'audit.
## Entités
- users(id, name, email, password_hash, role, active)
- clients(id, nom, telephone, email?, piece_identite?)
- room_types(id, name [VIP|Standard], active)
- room_rates(id, room_type_id, billing_unit [HALF_DAY|DAY], amount_xaf, effective_from, effective_to?, changed_by)
- rooms(id, room_type_id, number unique, capacity, operational_status)
- reservations(id, client_id, room_id, start_at, end_at, billing_unit, quantity, unit_price_snapshot_xaf, discount_type?, discount_value_xaf, total_xaf, status, created_by, checked_in_at?, checked_out_at?)
- reservation_occupants(id, reservation_id, client_id?, name?)
- payments(id, reservation_id, amount_xaf, method, status, paid_at, received_by, reference?)
- refunds(id, payment_id, amount_xaf, reason, approved_by, refunded_at)
- invoices(id, reservation_id, number unique, issued_at, subtotal_xaf, discount_xaf, total_xaf, status)
- invoice_lines(id, invoice_id, description, quantity, unit_price_xaf, line_total_xaf)
- receipts(id, payment_id, number unique, issued_at)
- audit_logs(id, actor_id, action, entity_type, entity_id, old_values?, new_values?, created_at)
## Services
AvailabilityService : contrôle du chevauchement `[start_at, end_at)` ; exclut les réservations annulées et refuse les chambres en maintenance.
PricingService : lit le tarif en vigueur, calcule les unités facturées selon la politique validée et fige prix/remise/total.
ReservationService : transaction avec verrouillage de la chambre, revalidation de disponibilité, enregistrement et gestion des prolongations.
CashService : paiements partiels, remboursements, rapprochement et solde.
InvoiceService : numérotation atomique, émission et génération PDF sans réécriture des factures émises.
DashboardService : agrégats filtrables, distinction facturé/encaissé.
## API REST indicative
POST /auth/login ; GET /me
GET/POST /clients ; GET/PATCH /clients/{id}
GET/POST /room-types ; GET/POST /room-types/{id}/rates
GET/POST /rooms ; GET/PATCH /rooms/{id} ; GET /availability?start=&end=
GET/POST /reservations ; GET/PATCH /reservations/{id} ; POST /reservations/{id}/check-in ; POST /reservations/{id}/check-out ; POST /reservations/{id}/extend
POST /reservations/{id}/payments ; POST /payments/{id}/refund
POST /reservations/{id}/invoices ; GET /invoices/{id}/pdf ; GET /receipts/{id}/pdf
GET /dashboard/cash ; GET /audit-logs
## Invariants
Montants en entiers FCFA ; validation côté serveur ; pas de modification silencieuse des factures émises ; prix figé à la création de la réservation ; contrôle de capacité ; restrictions de remise par rôle ; suppression logique ou archivage des documents financiers ; sauvegardes et tests automatisés.
