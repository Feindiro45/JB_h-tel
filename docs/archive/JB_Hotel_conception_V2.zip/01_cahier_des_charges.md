# JB Hôtel — Cahier des charges V2
## Périmètre
Application interne de gestion des chambres, réservations et caisse. Pas de site public ni paiement en ligne en V1.
## Rôles
Administrateur : comptes, chambres, types, tarifs, limites de remise, audit et rapports.
Caissière : clients, réservations, arrivées/départs, remises autorisées, encaissements, reçus et factures.
## Référentiel
Deux types de chambres : VIP et Standard. Chaque type possède un tarif **demi-journée** et **journée**, modifiables par l'administrateur. Chaque chambre a un numéro unique, une catégorie, une capacité maximale et un état opérationnel (active, maintenance, hors service).
## Réservation
Client principal réutilisable, occupants (nombre et identités facultatives selon politique), chambre, début et fin souhaités, formule demi-journée ou journée, quantité facturée, prix appliqué, remise, total, statut. Aucun horaire fixe imposé par l'hôtel ; les heures peuvent être saisies par le client. Les règles de durée et d'arrondi des demi-journées/journées sont configurables et restent à valider.
La disponibilité est calculée par chevauchement des périodes des réservations actives et des séjours en cours, et par état opérationnel. Éviter toute double réservation, y compris en accès simultané. Une réservation future ne rend pas la chambre occupée aujourd'hui.
## Caisse
Paiement intégral, acompte puis solde, ou paiement différé. Plusieurs paiements possibles par réservation ; chaque paiement génère un reçu. Modes de paiement configurables. Solde = montant dû - paiements nets encaissés. Annulations et remboursements enregistrés avec justification et autorisation.
Remise en pourcentage ou montant fixe ; plafond configurable pour la caissière ; auteur, date et motif conservés.
Facture imprimable à numéro unique avec lignes, prix historiques, remise, total et statut de règlement. Les factures émises ne sont pas modifiées lors des changements de tarif ; correction par avoir/document rectificatif.
## Historique tarifaire
Les changements de prix n'affectent que les nouvelles réservations. Chaque réservation conserve une copie du tarif unitaire et du total convenu ; chaque facture conserve ses lignes et montants. Conserver l'auteur, l'ancien tarif, le nouveau tarif et la date d'effet.
## Dashboard caisse
Filtres : période, type de chambre, chambre, caissière, statut. Indicateurs : réservations, occupation, facturé net, encaissé net, soldes dus, réductions, remboursements, annulations. Graphiques par jour, catégorie, moyen de paiement et utilisateur. Export CSV/PDF selon permissions. Distinguer chiffre d'affaires facturé et trésorerie encaissée.
## Règles à valider avant codage
Définition commerciale exacte de la demi-journée, calcul des jours multiples, règles d'arrondi, éventuel prix des prolongations, données d'identité légalement nécessaires, fiscalité et numérotation des factures, politiques d'annulation et de remboursement.
## Critères de recette
Aucune double réservation ; prix historiques intacts après changement tarifaire ; limite de capacité respectée ; acomptes et soldes exacts ; facture/reçu imprimables ; dashboard réconcilié avec paiements et factures.
