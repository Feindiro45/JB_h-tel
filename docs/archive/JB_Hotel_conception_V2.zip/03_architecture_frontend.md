# JB Hôtel — Architecture frontend V2
## Stack
React + TypeScript, React Router, TanStack Query, formulaires validés, client API Laravel, interface responsive, impression navigateur/PDF.
## Navigation
Connexion → Dashboard caisse → Disponibilité/Planning → Réservations → Clients → Paiements/Reçus → Factures → Rapports.
Administration : Types et tarifs, Chambres, Utilisateurs, Paramètres, Audit.
## Écrans
1. **Dashboard caisse** : KPI facturé, encaissé, solde, réductions, remboursements, occupation ; filtres et graphiques, liste des opérations récentes.
2. **Planning chambres** : VIP/Standard, disponible/occupée/réservée/maintenance, filtre par période, contrôle des conflits.
3. **Nouvelle réservation** : rechercher/créer client ; sélectionner chambre et occupants ; date et heure de début/fin selon choix du client ; formule demi-journée/journée ; quantité et prix calculés ; remise facultative ; paiement total/partiel/différé ; validation.
4. **Détail réservation** : statut, occupants, paiements, solde, prolongation, arrivée/départ, annulation, facture.
5. **Clients** : recherche par nom/téléphone et historique.
6. **Caisse** : saisie d'encaissement, reçus imprimables, remboursement autorisé, journal.
7. **Factures** : aperçu, impression PDF, liste filtrable, documents rectificatifs.
8. **Admin tarifs** : tableau VIP/Standard × demi-journée/journée ; mise à jour avec date d'effet ; historique. Message explicite : anciennes réservations et factures inchangées.
9. **Admin chambres** : numéro, type, capacité, maintenance.
## Composants
RoomCalendar, AvailabilityBadge, ReservationWizard, ClientSearch, OccupantEditor, PricingSummary, DiscountInput, PaymentSchedule, InvoicePreview, CashKpiCards, CashCharts, AuditTable.
## Règles UX
Afficher les FCFA sans décimales, dates/heures locales de Bangui (Africa/Bangui) ; demander confirmation des annulations/remboursements ; erreurs de conflit explicites ; boutons et pages conditionnés aux permissions. Le frontend ne décide jamais seul des montants définitifs : il affiche le calcul renvoyé par l'API.
## Tests
Parcours réservation immédiate/future ; chambre déjà réservée ; changement de tarif sans effet rétroactif ; acompte/solde ; remise ; impression ; dashboard et droits d'accès.
